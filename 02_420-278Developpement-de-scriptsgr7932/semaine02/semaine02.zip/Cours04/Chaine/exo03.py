print("\n\033[32mExo 3. Déterminer la longueur d'une chaîne de caractères.\033[0m")
print()

chaine = input("Tapez une chaîne de caractères: ")

# Déterminer la longueur de la chaîne de caractères
longueur = len(chaine)

print(f"La longueur de la chaîne de caractères est: {longueur}")