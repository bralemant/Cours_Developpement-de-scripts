print("\n\033[32mExo 2. Créer une liste d'entiers pour afficher la somme des éléments du tableau.\033[0m")
print()

# Création d'une liste d'entiers
liste_entiers = [1, 2, 3, 4, 5] 
 
# Calcul de la somme directement
somme = liste_entiers[0] + liste_entiers[1] + liste_entiers[2] + liste_entiers[3] + liste_entiers[4]

# Affichage de la somme
print("La somme des éléments est :", somme)