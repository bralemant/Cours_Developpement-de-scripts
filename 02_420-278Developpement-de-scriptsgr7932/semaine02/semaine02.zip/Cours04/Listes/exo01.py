print("\n\033[32mExo 1. Créer une liste d'entiers pour afficher chacun des éléments du tableau.\033[0m")
print()

# Création d'une liste d'entiers
liste_entiers = [1, 2, 3, 4, 5]  

# Affichage de chaque élément de la liste
print(liste_entiers[0])
print(liste_entiers[1])
print(liste_entiers[2])
print(liste_entiers[3])
print(liste_entiers[4])