print("\n\033[32mExo 3. Convertir une phrase en une liste de mots.\033[0m")
print()

# Déclaration de la phrase
phrase = "Le professeur Antoine possède de très bonnes connaissances académiques en programmation."

# Conversion de la phrase en une liste de mots
liste_mots = phrase.split()  

# Affichage de la liste de mots
print("La liste de mots est:", liste_mots)